"""Telegram catalog bot. Python 3.10+, one polling process per token/database."""
import html
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

from i18n import LANGUAGES, tr
from storage import Store

ROOT = Path(__file__).resolve().parent
PAGE = 10
LOG = logging.getLogger('catalog')


def esc(value):
    return html.escape(str(value))


def clean(value):
    return re.sub('[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200D\u20E3]', '', value).strip()


def date(value):
    return datetime.fromtimestamp(value, timezone.utc).strftime('%Y-%m-%d %H:%M') if value else '—'


class APIError(Exception):
    def __init__(self, code, description='', retry_after=0):
        super().__init__(f'Telegram API error {code}')  # Never expose the token/URL.
        self.code, self.description, self.retry_after = code, description, retry_after


class UncertainDelivery(Exception):
    pass


class Telegram:
    def __init__(self, token):
        self.base = f'https://api.telegram.org/bot{token}/'
        self.session = requests.Session()

    def call(self, method, **payload):
        upload = payload.pop('_photo_path', None)
        try:
            if upload:
                data = {k: json.dumps(v) if isinstance(v, (dict, list, bool)) else v for k, v in payload.items()}
                with open(upload, 'rb') as photo:
                    response = self.session.post(self.base+method, data=data,
                                                 files={'photo': (Path(upload).name, photo,
                                                        'image/png' if Path(upload).suffix == '.png' else 'image/jpeg')}, timeout=(10, 45))
            else:
                response = self.session.post(self.base+method, json=payload, timeout=(10, 45))
            result = response.json()
        except (requests.RequestException, ValueError) as error:
            raise UncertainDelivery() from None
        if not result.get('ok'):
            raise APIError(result.get('error_code', response.status_code), result.get('description', ''),
                           result.get('parameters', {}).get('retry_after', 0))
        return result['result']


class Bot:
    def __init__(self, store, api, admins, logo=None):
        self.s, self.api, self.admins = store, api, set(admins)
        self.logo = logo or ROOT / 'assets' / 'logo.png'

    def t(self, uid, key):
        return tr(self.s.user(uid)['lang'], key)

    def b(self, uid, key, data, style=None):
        return self.button(self.t(uid, key), data, style)

    @staticmethod
    def button(label, data, style=None):
        result = {'text': clean(label), 'callback_data': data}
        if style:
            result['style'] = style
        return result

    def state(self, uid, value=''):
        self.s.run('UPDATE users SET state=? WHERE id=?', (value, uid))

    def visit(self, uid, route):
        history = json.loads(self.s.user(uid)['navigation'] or '["home"]')
        if route in history:
            history = history[:history.index(route)+1]
        else:
            history.append(route)
        self.s.run('UPDATE users SET navigation=? WHERE id=?', (json.dumps(history[-30:]), uid))

    def back(self, uid):
        history = json.loads(self.s.user(uid)['navigation'] or '["home"]')
        if len(history) > 1:
            history.pop()
        route = history[-1] if history else 'home'
        self.s.run('UPDATE users SET navigation=? WHERE id=?', (json.dumps(history or ['home']), uid))
        return self.dispatch(uid, route)

    def alert(self, uid, text, header='logo'):
        # Keep the input state: an invalid key can be followed immediately by another key.
        self.visit(uid, 'notice')
        self.menu(uid, text, [[self.b(uid, 'back', 'back')]], header=header)

    def menu(self, uid, caption, rows, header='logo'):
        """One photo menu per user, caption always BELOW the header."""
        user = self.s.user(uid)
        for row in rows:
            for button in row:
                if button['text'] == self.t(uid, 'back'):
                    button['callback_data'] = 'back'
        payload = dict(chat_id=uid, caption=('\n' if header in ('files', 'profile') else '')+clean(caption), parse_mode='HTML',
                       show_caption_above_media=False, reply_markup={'inline_keyboard': rows})
        cache_key = 'photo' if header == 'logo' else 'photo:'+header
        cached = self.s.one('SELECT value FROM meta WHERE key=?', (cache_key,))
        photo_path = self.logo if header == 'logo' else ROOT / 'assets' / (header+'.jpg')
        header_key = f'menu_header:{uid}'
        current = self.s.one('SELECT value FROM meta WHERE key=?', (header_key,))
        def remember(message):
            self.s.run('INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)', (header_key, header))
            if message.get('photo'):
                self.s.run('INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)',
                           (cache_key, message['photo'][-1]['file_id']))
        if user['menu']:
            try:
                if not current or current['value'] != header:
                    media = dict(type='photo', media=cached['value'] if cached else 'attach://photo',
                                 caption=payload['caption'], parse_mode='HTML', show_caption_above_media=False)
                    upload = {} if cached else {'_photo_path': photo_path}
                    message = self.api.call('editMessageMedia', chat_id=uid, message_id=user['menu'],
                                            media=media, reply_markup=payload['reply_markup'], **upload)
                    remember(message)
                else:
                    self.api.call('editMessageCaption', message_id=user['menu'], **payload)
                return
            except APIError as error:
                if 'message is not modified' in error.description.lower():
                    remember({})
                    return
                # Only replace a menu confirmed to have been deleted. Never replace on timeout.
                if error.code != 400 or 'message to edit not found' not in error.description.lower():
                    raise
                self.s.run('UPDATE users SET menu=NULL WHERE id=?', (uid,))
        if cached:
            payload['photo'] = cached['value']
        else:
            payload['_photo_path'] = photo_path
        message = self.api.call('sendPhoto', **payload)
        self.s.run('UPDATE users SET menu=? WHERE id=?', (message['message_id'], uid))
        remember(message)

    def delete_input(self, message):
        try:
            self.api.call('deleteMessage', chat_id=message['chat']['id'], message_id=message['message_id'])
        except (APIError, UncertainDelivery):
            pass

    def home(self, uid, notice=''):
        self.state(uid)
        if notice:
            self.visit(uid, 'home')
            return self.alert(uid, notice)
        user = self.s.user(uid)
        if user['banned']:
            return self.menu(uid, self.t(uid, 'banned'), [])
        if uid not in self.admins and user['expires'] <= time.time():
            self.visit(uid, 'home')
            return self.menu(uid, self.t(uid, 'locked'),
                             [[self.b(uid, 'profile', 'profile')]])
        self.catalog(uid, 0, notice)

    def language(self, uid):
        self.visit(uid, 'language')
        labels = [('pt', '🇧🇷 PT BR'), ('en', '🇺🇸 ENGLISH'), ('ru', '🇷🇺 RUSSO'), ('zh', '🇨🇳 CHINÊS')]
        buttons = [{'text': label, 'callback_data': 'lang:'+lang} for lang, label in labels]
        self.menu(uid, self.t(uid, 'language'),
                  [buttons[:2], buttons[2:]]
                  + [[self.b(uid, 'back', 'back')]])

    def profile(self, uid, notice=''):
        self.state(uid)
        self.visit(uid, 'profile')
        if notice:
            return self.alert(uid, notice, header='profile')
        user = self.s.user(uid)
        total = self.s.one("SELECT count(*) n FROM downloads WHERE user_id=? AND status='sent'", (uid,))['n']
        key = self.s.one('SELECT * FROM keys WHERE id=?', (user['current_key'],))
        status = 'admin_access' if uid in self.admins else ('active' if user['expires'] > time.time() else 'inactive')
        def field(label, value):
            return f'{label}: <code>{esc(value)}</code>'
        identity = [field('ID', uid),
                 field(self.t(uid, 'username'), '@'+user['username'] if user['username'] else self.t(uid, 'no_username')),
                 field(self.t(uid, 'registered'), date(user['registered']) if user['registered'] else self.t(uid, 'unknown'))]
        activity = [field(self.t(uid, 'downloaded'), total),
                    field(self.t(uid, 'language_name'), LANGUAGES.get(user['lang'], LANGUAGES['pt']))]
        subscription = [field(self.t(uid, 'status'), self.t(uid, status))]
        if key:
            subscription += [field('Key ID', '#'+str(key['id'])), field(self.t(uid, 'duration'), key['days']),
                             field(self.t(uid, 'activated_on'), date(user['expires']-key['days']*86400))]
        if uid not in self.admins:
            subscription += [field(self.t(uid, 'expires'), date(user['expires']))]
        lines = []
        for heading, fields in [('identity', identity), ('activity', activity), ('subscription', subscription)]:
            lines += ['', '<b>'+self.t(uid, heading)+'</b>']
            lines += [('└─ ' if index == len(fields)-1 else '├─ ')+value
                      for index, value in enumerate(fields)]
        self.menu(uid, '\n'.join(lines), [[self.b(uid, 'change_language', 'language')],
                  [self.b(uid, 'key', 'key')], [self.b(uid, 'back', 'back')]], header='profile')

    def pager(self, page, total, prefix):
        buttons = []
        if page > 0:
            buttons.append(self.button('‹', f'{prefix}:{page-1}'))
        if (page+1)*PAGE < total:
            buttons.append(self.button('›', f'{prefix}:{page+1}'))
        return [buttons] if buttons else []

    def catalog(self, uid, page=0, notice='', news=False):
        user = self.s.user(uid)
        if uid not in self.admins and user['expires'] <= time.time():
            return self.home(uid)
        condition = "f.active=1" + (" AND NOT EXISTS (SELECT 1 FROM downloads n WHERE n.file_id=f.id AND n.user_id=? AND n.status='sent')" if news else '')
        args = (uid,) if news else ()
        total = self.s.one('SELECT count(*) n FROM files f WHERE '+condition, args)['n']
        route, download_route = ('news', 'ndl') if news else ('cat', 'dl')
        page = max(0, min(page, max(0, (total-1)//PAGE)))
        self.visit(uid, f'{route}:{page}')
        if notice:
            return self.alert(uid, notice, header='files')
        files = self.s.all('SELECT f.*,d.status FROM files f LEFT JOIN downloads d ON d.file_id=f.id AND d.user_id=? '
                           'WHERE '+condition+' ORDER BY f.id LIMIT ? OFFSET ?', (uid, *args, PAGE, page*PAGE))
        buttons = []
        for file in files:
            buttons.append(self.button(f"{file['title']} #{file['display_id'] or file['id']}", f"{download_route}:{file['id']}:{page}",
                                       'success' if file['status'] == 'sent' else None))
        rows = [buttons[i:i+2] for i in range(0, len(buttons), 2)]
        caption = '• '+self.t(uid, 'hint')+'\n• '+self.t(uid, 'once_hint')
        if not files:
            caption += '\n\n'+self.t(uid, 'news_empty' if news else 'empty')
        caption += '\n\n'+self.t(uid, 'page')+f': {page+1} / {max(1, (total+PAGE-1)//PAGE)}'
        rows += self.pager(page, total, route)
        rows += [[self.b(uid, 'profile', 'profile')]]
        if uid in self.admins:
            rows += [[self.b(uid, 'admin', 'admin')]]
        self.menu(uid, caption, rows, header='files')

    def download(self, uid, fid, page, news=False):
        status = self.s.reserve(uid, fid, uid in self.admins)
        if status != 'reserved':
            return self.home(uid, self.t(uid, status)) if status in ('banned', 'locked') else self.catalog(uid, page, self.t(uid, status), news=news)
        file = self.s.one('SELECT * FROM files WHERE id=?', (fid,))
        notice = ''
        try:
            result = self.api.call('copyMessage', chat_id=uid, from_chat_id=file['source_chat'],
                                   message_id=file['source_message'])
        except APIError as error:
            if error.code in (400, 403, 429):
                # Explicit rejection: no delivery occurred, so another attempt is safe.
                self.s.run('DELETE FROM downloads WHERE user_id=? AND file_id=?', (uid, fid))
                notice = self.t(uid, 'failed')
            else:
                notice = self.t(uid, 'uncertain')
        except UncertainDelivery:
            notice = self.t(uid, 'uncertain')
        else:
            self.s.run("UPDATE downloads SET status='sent',message_id=? WHERE user_id=? AND file_id=?",
                       (result['message_id'], uid, fid))
        self.catalog(uid, page, notice, news=news)

    def admin(self, uid, notice=''):
        self.state(uid)
        self.visit(uid, 'admin')
        if notice:
            return self.alert(uid, notice)
        self.menu(uid, '<b>'+self.t(uid, 'admin')+'</b>',
                  [[self.b(uid, 'add', 'a:add')],
                   [self.b(uid, 'files', 'a:files:0'), self.b(uid, 'keys', 'a:keys:0')],
                   [self.b(uid, 'users', 'a:users:0'), self.b(uid, 'stats', 'a:stats')],
                   [self.b(uid, 'rename_all', 'a:rename_all')],
                   [self.b(uid, 'delete_all', 'a:delete_all', 'danger')],
                   [self.b(uid, 'broadcast', 'a:broadcast')],
                   [self.b(uid, 'audit', 'a:audit')], [self.b(uid, 'back', 'back')]])

    def prompt(self, uid, state, text, back='admin'):
        self.state(uid, state)
        self.visit(uid, state)
        self.menu(uid, self.t(uid, text), [[self.b(uid, 'back', back)]])

    def listing(self, uid, kind, page):
        # Table identifiers are selected exclusively from this constant whitelist.
        table, singular = {'files': ('files', 'file'), 'keys': ('keys', 'key'), 'users': ('users', 'user')}[kind]
        total = self.s.one(f'SELECT count(*) n FROM {table}')['n']
        page = max(0, min(page, max(0, (total-1)//PAGE)))
        self.visit(uid, f'a:{kind}:{page}')
        records = self.s.all(f'SELECT * FROM {table} ORDER BY id DESC LIMIT ? OFFSET ?', (PAGE, PAGE*page))
        rows = []
        for record in records:
            label = f"#{(record['display_id'] or record['id']) if kind == 'files' else record['id']}"
            if kind == 'files':
                label += ' · ' + record['title'] + ' · ' + self.t(uid, 'active' if record['active'] else 'inactive')
            elif kind == 'users':
                label += ' · ' + record['name'][:30]
            else:
                status = 'revoked' if record['revoked'] else ('used' if record['used_by'] else ('inactive' if record['redeem_until'] <= time.time() else 'active'))
                label += ' · '+self.t(uid, status)
            rows.append([self.button(label, f"a:{singular}:{record['id']}")])
        rows += self.pager(page, total, 'a:'+kind)
        if kind == 'keys':
            rows += [[self.b(uid, 'create', 'a:create')]]
        if kind == 'users':
            rows += [[self.b(uid, 'lookup', 'a:lookup')]]
        if kind == 'files':
            rows += [[self.b(uid, 'add', 'a:add')], [self.b(uid, 'rename_all', 'a:rename_all')]]
            rows += [[self.b(uid, 'delete_all', 'a:delete_all', 'danger')]]
        self.menu(uid, '<b>'+self.t(uid, kind)+f'</b> · {total}\n\n'+self.t(uid, 'page')+
                  f': {page+1} / {max(1, (total+PAGE-1)//PAGE)}', rows+[[self.b(uid, 'back', 'admin')]])

    def detail(self, uid, kind, rid):
        self.visit(uid, f'a:{kind}:{rid}')
        table = {'file': 'files', 'key': 'keys', 'user': 'users'}[kind]
        item = self.s.one(f'SELECT * FROM {table} WHERE id=?', (rid,))
        if not item:
            return self.admin(uid, self.t(uid, 'invalid'))
        number = (item['display_id'] or rid) if kind == 'file' else rid
        caption = f'<b>#{number}</b>\n'
        rows = []
        if kind == 'file':
            caption += esc(item['title'])+'\n'+self.t(uid, 'active' if item['active'] else 'inactive')
            count = self.s.one("SELECT count(*) n FROM downloads WHERE file_id=? AND status='sent'", (rid,))['n']
            caption += '\n'+self.t(uid, 'deliveries')+f': {count}'
            rows = [[self.b(uid, 'rename', f'a:rename:{rid}'), self.b(uid, 'replace', f'a:replace:{rid}')],
                    [self.b(uid, 'disable' if item['active'] else 'enable', f'a:confirm:toggle:{rid}:{1-item["active"]}')]]
        elif kind == 'key':
            caption += self.t(uid, 'duration')+f": {item['days']}\n"+self.t(uid, 'redeem_until')+': '+date(item['redeem_until'])
            status = 'revoked' if item['revoked'] else ('used' if item['used_by'] else ('inactive' if item['redeem_until'] <= time.time() else 'active'))
            caption += '\n'+self.t(uid, status)
            if item['used_by']:
                caption += f"\nID: {item['used_by']}"
            if not item['revoked']:
                rows = [[self.b(uid, 'revoke', f'a:confirm:revoke:{rid}', 'danger')]]
        else:
            caption += esc(item['name'])+'\n'+self.t(uid, 'expires')+': '+date(item['expires'])
            count = self.s.one("SELECT count(*) n FROM downloads WHERE user_id=? AND status='sent'", (rid,))['n']
            caption += '\n'+self.t(uid, 'deliveries')+f': {count}'
            if rid not in self.admins:
                rows = [[self.b(uid, 'unban' if item['banned'] else 'ban', f'a:confirm:ban:{rid}:{1-item["banned"]}', 'danger')],
                        [self.b(uid, 'expire', f'a:confirm:expire:{rid}')]]
        self.menu(uid, caption, rows+[[self.b(uid, 'back', f'a:{table}:0')]])

    def mutate(self, uid, action):
        parts = action.split(':')
        op, rid = parts[0], int(parts[1])
        with self.s.transaction():
            if op == 'toggle':
                self.s.run('UPDATE files SET active=? WHERE id=?', (int(parts[2]) == 1, rid))
            elif op == 'revoke':
                self.s.run('UPDATE keys SET revoked=1 WHERE id=?', (rid,))
                self.s.run('UPDATE users SET expires=0,current_key=NULL WHERE current_key=?', (rid,))
            elif op == 'ban' and rid not in self.admins:
                self.s.run('UPDATE users SET banned=? WHERE id=?', (int(parts[2]) == 1, rid))
            elif op == 'expire' and rid not in self.admins:
                self.s.run('UPDATE users SET expires=0,current_key=NULL WHERE id=?', (rid,))
            else:
                raise ValueError('action')
            self.s.log(uid, {'toggle': 'files', 'revoke': 'revoke', 'ban': 'ban', 'expire': 'expire'}[op], rid)
        kind = {'toggle': 'file', 'revoke': 'key', 'ban': 'user', 'expire': 'user'}[op]
        self.detail(uid, kind, rid)

    def admin_callback(self, uid, data):
        parts = data.split(':')
        op = parts[1]
        if op == 'broadcast':
            return self.broadcast_panel(uid)
        if op == 'broadcast_compose':
            return self.prompt(uid, data, 'broadcast_prompt')
        if op == 'broadcast_review':
            return self.broadcast_confirmation(uid, int(parts[2]))
        if op in ('files', 'keys', 'users'):
            return self.listing(uid, op, int(parts[2]))
        if op in ('file', 'key', 'user'):
            return self.detail(uid, op, int(parts[2]))
        if op in ('add', 'create', 'lookup', 'rename_all'):
            return self.prompt(uid, 'a:'+op, {'add': 'add_prompt', 'create': 'days_prompt', 'lookup': 'id_prompt',
                                            'rename_all': 'rename_all_prompt'}[op])
        if op in ('rename', 'replace'):
            return self.prompt(uid, data, 'name_prompt' if op == 'rename' else 'replace_prompt', 'a:file:'+parts[2])
        if op == 'delete_all':
            self.visit(uid, data)
            snapshot = self.s.one('SELECT count(*) n,coalesce(max(id),0) last FROM files')
            if not snapshot['n']:
                return self.admin(uid, self.t(uid, 'empty'))
            self.state(uid, f"delete_all:{snapshot['last']}")
            return self.menu(uid, self.t(uid, 'delete_all_confirm').format(count=snapshot['n']),
                             [[self.b(uid, 'yes', 'a:execute', 'danger')], [self.b(uid, 'back', 'back')]])
        if op == 'confirm':
            self.visit(uid, data)
            action = ':'.join(parts[2:])
            self.state(uid, 'confirm:'+action)
            return self.menu(uid, self.t(uid, 'confirm')+f'\nID: {esc(parts[3])}',
                             [[self.b(uid, 'yes', 'a:execute', 'danger')], [self.b(uid, 'back', 'admin')]])
        if op == 'execute':
            state = self.s.user(uid)['state']
            if state.startswith('broadcast:'):
                job_id = int(state.split(':')[1])
                with self.s.transaction():
                    changed = self.s.run("UPDATE broadcasts SET status='queued' WHERE id=? AND admin_id=? AND status='draft'", (job_id, uid)).rowcount
                    if changed:
                        self.s.log(uid, 'broadcast', job_id)
                    self.state(uid)
                return self.broadcast_panel(uid, self.t(uid, 'broadcast_queued'))
            if state.startswith('delete_all:'):
                last = int(state.split(':')[1])
                with self.s.transaction():
                    # Keep delivery records and the AUTOINCREMENT sequence; never reuse old IDs.
                    removed = self.s.run('DELETE FROM files WHERE id<=?', (last,)).rowcount
                    remaining = self.s.all('SELECT id FROM files ORDER BY id')
                    for number, file in enumerate(remaining, 1):
                        self.s.run('UPDATE files SET display_id=? WHERE id=?', (number, file['id']))
                    self.s.run("UPDATE meta SET value=? WHERE key='next_file_number'", (str(len(remaining)+1),))
                    self.s.log(uid, 'delete_all', removed)
                    self.state(uid)
                return self.admin(uid, self.t(uid, 'deleted_all').format(count=removed))
            if state.startswith('rename_all:'):
                title = state.removeprefix('rename_all:')
                with self.s.transaction():
                    self.s.run('UPDATE files SET title=?', (title,))
                    self.s.log(uid, 'rename_all')
                    self.state(uid)
                return self.admin(uid, self.t(uid, 'saved'))
            if state.startswith('confirm:'):
                self.state(uid)
                return self.mutate(uid, state.removeprefix('confirm:'))
            return self.admin(uid)
        if op == 'stats':
            self.visit(uid, data)
            stats = [('users', self.s.one('SELECT count(*) n FROM users')['n']),
                     ('files', self.s.one('SELECT count(*) n FROM files')['n']),
                     ('keys', self.s.one('SELECT count(*) n FROM keys')['n']),
                     ('deliveries', self.s.one("SELECT count(*) n FROM downloads WHERE status='sent'")['n']),
                     ('pending', self.s.one("SELECT count(*) n FROM downloads WHERE status='pending'")['n'])]
            return self.menu(uid, '<b>'+self.t(uid, 'stats')+'</b>\n\n'+'\n'.join(self.t(uid, k)+f': {v}' for k,v in stats),
                             [[self.b(uid, 'pending', 'a:pending')], [self.b(uid, 'back', 'admin')]])
        if op == 'pending':
            self.visit(uid, data)
            rows = self.s.all("SELECT user_id,file_id FROM downloads WHERE status='pending' ORDER BY created DESC LIMIT 10")
            caption = self.t(uid, 'uncertain')+'\n\n'+'\n'.join(f"User {r['user_id']} → #{r['file_id']}" for r in rows)
            return self.menu(uid, caption, [[self.b(uid, 'back', 'a:stats')]])
        if op == 'audit':
            self.visit(uid, data)
            records = self.s.all('SELECT * FROM audit ORDER BY id DESC LIMIT 8')
            caption = '<b>'+self.t(uid, 'audit')+'</b>\n\n'+'\n'.join(
                f"{date(r['created'])} · {r['actor']}\n{self.t(uid, r['action'])} → #{r['target']}" for r in records)
            return self.menu(uid, caption, [[self.b(uid, 'back', 'admin')]])

    def broadcast_panel(self, uid, notice=''):
        self.state(uid)
        self.visit(uid, 'a:broadcast')
        if notice:
            return self.alert(uid, notice)
        job = self.s.one("SELECT * FROM broadcasts WHERE admin_id=? AND status!='draft' ORDER BY id DESC LIMIT 1", (uid,))
        caption = '<b>'+self.t(uid, 'broadcast')+'</b>'
        if job:
            counts = {r['status']: r['n'] for r in self.s.all(
                'SELECT status,count(*) n FROM broadcast_recipients WHERE broadcast_id=? GROUP BY status', (job['id'],))}
            caption += f"\n\nID: <code>{job['id']}</code>"
            for status in ('pending', 'sending', 'sent', 'failed', 'uncertain'):
                caption += '\n'+self.t(uid, 'broadcast_'+status)+': '+str(counts.get(status, 0))
        self.menu(uid, caption, [[self.b(uid, 'broadcast_new', 'a:broadcast_compose')],
                  [self.b(uid, 'refresh', 'a:broadcast')], [self.b(uid, 'back', 'back')]])

    def prepare_broadcast(self, uid, message):
        supported = ('text', 'document', 'photo', 'video', 'audio', 'voice', 'animation',
                     'sticker', 'video_note', 'contact', 'location', 'venue', 'dice')
        if message.get('has_protected_content') or message.get('media_group_id') or not any(k in message for k in supported):
            return self.alert(uid, self.t(uid, 'broadcast_unsupported'))
        with self.s.transaction():
            job_id = self.s.run('INSERT INTO broadcasts(admin_id,source_message,created) VALUES(?,?,?)',
                                (uid, message['message_id'], time.time())).lastrowid
            self.s.run('INSERT INTO broadcast_recipients(broadcast_id,user_id) SELECT ?,id FROM users', (job_id,))
        # Preserve the source message, including entities, caption and media: copyMessage uses it verbatim.
        self.broadcast_confirmation(uid, job_id)

    def broadcast_confirmation(self, uid, job_id):
        job = self.s.one("SELECT * FROM broadcasts WHERE id=? AND admin_id=? AND status='draft'", (job_id, uid))
        if not job:
            return self.broadcast_panel(uid)
        self.state(uid, f'broadcast:{job_id}')
        self.visit(uid, f'a:broadcast_review:{job_id}')
        count = self.s.one('SELECT count(*) n FROM broadcast_recipients WHERE broadcast_id=?', (job_id,))['n']
        self.menu(uid, self.t(uid, 'broadcast_confirm').format(count=count),
                  [[self.b(uid, 'yes', 'a:execute')], [self.b(uid, 'back', 'back')]])

    def process_broadcast(self):
        """Deliver one queued copy; persisted reservation prevents duplicate sends after restart."""
        with self.s.transaction():
            recipient = self.s.one("SELECT r.*,b.admin_id,b.source_message FROM broadcast_recipients r "
                                   "JOIN broadcasts b ON b.id=r.broadcast_id WHERE b.status='queued' "
                                   "AND r.status='pending' AND r.next_at<=? ORDER BY r.broadcast_id,r.user_id LIMIT 1",
                                   (time.time(),))
            if not recipient:
                return False
            job_id, uid = recipient['broadcast_id'], recipient['user_id']
            self.s.run("UPDATE broadcast_recipients SET status='sending' WHERE broadcast_id=? AND user_id=?", (job_id, uid))
        status, message_id, next_at = 'failed', None, 0
        try:
            if recipient['admin_id'] not in self.admins:
                raise APIError(403)
            result = self.api.call('copyMessage', chat_id=uid, from_chat_id=recipient['admin_id'],
                                   message_id=recipient['source_message'])
            status, message_id = 'sent', result['message_id']
        except APIError as error:
            if error.code == 429:
                status, next_at = 'pending', time.time()+max(1, error.retry_after)
                # Honor the server's rate-limit delay for the entire queue.
                self.s.run("UPDATE broadcast_recipients SET next_at=max(next_at,?) WHERE status='pending'", (next_at,))
            elif error.code not in (400, 403):
                status = 'uncertain'
        except UncertainDelivery:
            status = 'uncertain'
        with self.s.transaction():
            self.s.run('UPDATE broadcast_recipients SET status=?,message_id=?,next_at=? WHERE broadcast_id=? AND user_id=?',
                       (status, message_id, next_at, job_id, uid))
            self.s.run("UPDATE broadcasts SET status='finished' WHERE id=? AND NOT EXISTS "
                       "(SELECT 1 FROM broadcast_recipients WHERE broadcast_id=? AND status IN ('pending','sending'))",
                       (job_id, job_id))
        return True

    @staticmethod
    def media(message):
        if message.get('has_protected_content'):
            return None
        for kind in ('document', 'video', 'audio', 'animation', 'voice', 'photo'):
            if kind in message:
                obj = message[kind]
                title = obj.get('file_name') if isinstance(obj, dict) else None
                return clean((message.get('caption') or title or kind).split('\n')[0][:60]) or kind
        return None

    def ingest(self, uid, message, replacement=None):
        title = self.media(message)
        if not title:
            return self.alert(uid, self.t(uid, 'media_only'))
        with self.s.transaction():
            if replacement:
                if not self.s.one('SELECT id FROM files WHERE id=?', (replacement,)):
                    raise ValueError('file')
                self.s.run('UPDATE files SET source_chat=?,source_message=? WHERE id=?',
                           (uid, message['message_id'], replacement))
                fid = replacement
                self.s.log(uid, 'replace', fid)
            else:
                next_number = int(self.s.one("SELECT value FROM meta WHERE key='next_file_number'")['value'])
                next_number = max(next_number, self.s.one('SELECT coalesce(max(coalesce(display_id,id)),0)+1 n FROM files')['n'])
                inserted = self.s.run('INSERT OR IGNORE INTO files(title,source_chat,source_message,display_id) VALUES(?,?,?,?)',
                                      (title, uid, message['message_id'], next_number))
                if inserted.rowcount:
                    self.s.run("UPDATE meta SET value=? WHERE key='next_file_number'", (str(next_number+1),))
                fid = self.s.one('SELECT id FROM files WHERE source_chat=? AND source_message=?',
                                 (uid, message['message_id']))['id']
                self.s.log(uid, 'add', fid)
        # Keep source messages: copyMessage needs them for future deliveries.
        if replacement:
            self.state(uid)
            return self.detail(uid, 'file', fid)
        number = self.s.one('SELECT coalesce(display_id,id) n FROM files WHERE id=?', (fid,))['n']
        self.alert(uid, self.t(uid, 'added')+f': #{number}\n{esc(title)}')

    def handle_message(self, message):
        if message['chat']['type'] != 'private' or message.get('from', {}).get('is_bot'):
            return
        user = self.s.register(message['from'])
        uid = user['id']
        text = message.get('text', '').strip()
        command = text.split(' ')[0].split('@')[0].lower()
        if user['banned']:
            self.delete_input(message)
            return self.menu(uid, self.t(uid, 'banned'), [])
        if command in ('/start', '/news', '/profile', '/preferences', '/admin', '/cancel', '/id'):
            self.delete_input(message)
            self.state(uid)
            if command == '/id':
                return self.profile(uid)
            if command in ('/preferences', '/profile'):
                return self.profile(uid)
            if command == '/news':
                return self.catalog(uid, news=True)
            if command == '/admin' and uid in self.admins:
                return self.admin(uid)
            if command == '/start':
                self.visit(uid, 'home')
                if not user['lang']:
                    return self.language(uid)
            return self.home(uid)
        if command == '/app':
            app_url = os.environ.get('MINIAPP_URL', '').strip()
            if not app_url.startswith('https://'):
                return self.alert(uid, 'Mini App indisponível: configure MINIAPP_URL com um endereço HTTPS público.')
            self.menu(uid, 'Files', [[{'text': 'Open Mini App', 'web_app': {'url': app_url}}]])
            return
        if uid in self.admins and user['state'] == 'a:broadcast_compose':
            return self.prepare_broadcast(uid, message)
        if uid in self.admins and user['state'].startswith('broadcast:'):
            # Additional content while reviewing an announcement must not enter the catalog.
            return self.alert(uid, self.t(uid, 'broadcast_review'))
        if uid in self.admins and self.media(message):
            # All configured admins can upload directly, even on their first interaction.
            # Telegram delivers one update per file, including every member of an album.
            if user['state'].startswith('a:replace:'):
                return self.ingest(uid, message, int(user['state'].split(':')[2]))
            self.state(uid)
            self.visit(uid, 'admin')
            return self.ingest(uid, message)
        if uid in self.admins and (user['state'] == 'a:add' or user['state'].startswith('a:replace:')):
            return self.alert(uid, self.t(uid, 'media_only'))
        self.delete_input(message)
        if user['state'] == 'key':
            result = self.s.redeem(uid, text)
            if result == 'activated':
                return self.profile(uid, self.t(uid, result))
            return self.alert(uid, self.t(uid, result))
        if uid in self.admins:
            if user['state'] == 'a:rename_all':
                title = clean(text)
                if not 1 <= len(title) <= 60:
                    return self.prompt(uid, 'a:rename_all', 'rename_all_prompt')
                self.state(uid, 'rename_all:'+title)
                self.visit(uid, 'a:rename_review')
                return self.menu(uid, self.t(uid, 'rename_all_confirm')+'\n\n<code>'+esc(title)+'</code>',
                                 [[self.b(uid, 'yes', 'a:execute')], [self.b(uid, 'back', 'back')]])
            if user['state'] == 'a:create':
                try:
                    days, redemption = map(int, text.split())
                    kid, raw = self.s.create_key(uid, days, redemption)
                except ValueError:
                    return self.prompt(uid, 'a:create', 'days_prompt')
                self.state(uid)
                self.visit(uid, 'a:keys:0')
                self.visit(uid, 'a:key_created')
                return self.menu(uid, self.t(uid, 'created')+f'\n\n<code>{raw}</code>\nID: {kid}',
                                 [[{'text': self.t(uid, 'copy'), 'copy_text': {'text': raw}}], [self.b(uid, 'back', 'back')]])
            if user['state'] == 'a:lookup':
                if not text.isdigit():
                    return self.prompt(uid, 'a:lookup', 'id_prompt')
                self.state(uid)
                return self.detail(uid, 'user', int(text))
            if user['state'].startswith('a:rename:'):
                text = clean(text)
                if not 1 <= len(text) <= 60:
                    return self.prompt(uid, user['state'], 'name_prompt')
                fid = int(user['state'].split(':')[2])
                self.s.run('UPDATE files SET title=? WHERE id=?', (text, fid))
                self.s.log(uid, 'rename', fid)
                self.state(uid)
                return self.detail(uid, 'file', fid)
        self.home(uid)

    def callback(self, query):
        message = query.get('message', {})
        if message.get('chat', {}).get('type') != 'private':
            return
        user = self.s.register(query['from'])
        uid = user['id']
        data = query.get('data', '')
        try:
            self.api.call('answerCallbackQuery', callback_query_id=query['id'])
        except (APIError, UncertainDelivery):
            pass
        if message['chat']['id'] != uid or message.get('message_id') != user['menu']:
            return
        if user['banned']:
            return self.menu(uid, self.t(uid, 'banned'), [])
        return self.dispatch(uid, data)

    def dispatch(self, uid, data):
        if data == 'back':
            self.state(uid)
            return self.back(uid)
        if data == 'admin' or data.startswith('a:'):
            if uid not in self.admins:
                return self.home(uid, self.t(uid, 'forbidden'))
            if data != 'a:execute':
                self.state(uid)
            return self.admin(uid) if data == 'admin' else self.admin_callback(uid, data)
        self.state(uid)
        if data == 'noop':
            return
        if data == 'home':
            return self.home(uid)
        if data == 'language':
            return self.language(uid)
        if data.startswith('lang:'):
            lang = data.split(':')[1]
            if lang in LANGUAGES:
                self.s.run('UPDATE users SET lang=? WHERE id=?', (lang, uid))
                return self.back(uid)
        if data in ('prefs', 'profile'):
            return self.profile(uid)
        if data == 'key':
            return self.prompt(uid, 'key', 'key_prompt', 'profile')
        if data.startswith('cat:'):
            return self.catalog(uid, int(data.split(':')[1]))
        if data.startswith('news:'):
            return self.catalog(uid, int(data.split(':')[1]), news=True)
        if data.startswith('ndl:'):
            _, fid, page = data.split(':')
            return self.download(uid, int(fid), int(page), news=True)
        if data.startswith('dl:'):
            _, fid, page = data.split(':')
            return self.download(uid, int(fid), int(page))

    def handle(self, update):
        if 'message' in update:
            self.handle_message(update['message'])
        elif 'callback_query' in update:
            self.callback(update['callback_query'])


def load_env():
    path = ROOT / '.env'
    if path.exists():
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                key, value = line.split('=', 1)
                os.environ.setdefault(key.strip(), value.strip().strip('\"').strip("'"))


def main():
    load_env()
    token = os.environ.get('BOT_TOKEN', '')
    try:
        admins = {int(uid.strip()) for uid in os.environ.get('ADMIN_IDS', '').split(',') if uid.strip()}
    except ValueError:
        raise SystemExit('ADMIN_IDS deve conter somente IDs numéricos separados por vírgulas.')
    if ':' not in token or not admins or any(uid <= 0 for uid in admins):
        raise SystemExit('Configure BOT_TOKEN e ADMIN_IDS no arquivo .env. Veja README.md.')
    for asset in ('logo.png', 'files.jpg', 'profile.jpg'):
        if not (ROOT / 'assets' / asset).exists():
            raise SystemExit(f'assets/{asset} não encontrado.')
    (ROOT / 'data').mkdir(exist_ok=True)
    # OS lock prevents two local workers from consuming the same updates.
    lock = open(ROOT / 'data' / 'worker.lock', 'a+b')
    lock.seek(0)
    lock.write(b'0')
    lock.flush()
    lock.seek(0)
    try:
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        raise SystemExit('Já existe uma instância usando este banco.')
    store = Store(ROOT / 'data' / 'catalog.sqlite3')
    api = Telegram(token)
    bot = Bot(store, api, admins)
    store.run("UPDATE broadcast_recipients SET status='uncertain' WHERE status='sending'")
    store.run("UPDATE broadcasts SET status='finished' WHERE status='queued' AND NOT EXISTS "
              "(SELECT 1 FROM broadcast_recipients r WHERE r.broadcast_id=broadcasts.id AND r.status='pending')")
    try:
        info = api.call('getMe')
        webhook = api.call('getWebhookInfo')
        if webhook.get('url'):
            raise SystemExit('Este token tem um webhook ativo. Remova-o antes de iniciar o polling.')
        previous = store.one("SELECT value FROM meta WHERE key='bot_id'")
        if previous and previous['value'] != str(info['id']):
            raise SystemExit('Este banco pertence a outro bot. Use uma pasta data separada.')
        store.run("INSERT OR REPLACE INTO meta(key,value) VALUES('bot_id',?)", (str(info['id']),))
        api.call('setMyCommands', commands=[{'command': 'start', 'description': 'Open / Abrir'},
                 {'command': 'news', 'description': 'New files / Arquivos não recebidos'},
                 {'command': 'profile', 'description': 'Profile / Perfil'},
                 {'command': 'app', 'description': 'Open Mini App'},
                 {'command': 'id', 'description': 'Your ID / Seu ID'}])
        miniapp_url = os.environ.get('MINIAPP_URL', '').strip()
        if miniapp_url:
            from urllib.parse import urlsplit
            parsed = urlsplit(miniapp_url)
            if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password:
                raise SystemExit('MINIAPP_URL deve ser um endereço HTTPS público válido.')
            api.call('setChatMenuButton', menu_button={'type': 'web_app', 'text': 'Files',
                                                       'web_app': {'url': miniapp_url}})
    except (APIError, UncertainDelivery):
        raise SystemExit('Falha ao conectar ao Telegram. Confira o token e a conexão.') from None
    LOG.info('Bot iniciado: @%s', info['username'])
    from miniapp_server import MiniApp, start as start_miniapp
    miniapp = MiniApp(store, api, token, admins)
    try:
        start_miniapp(miniapp, port=int(os.environ.get('MINIAPP_PORT', '8765')))
    except OSError:
        LOG.exception('Mini App server could not start')
    stored = store.one("SELECT value FROM meta WHERE key='offset'")
    offset = int(stored['value']) if stored else 0
    while True:
        try:
            queued = store.one("SELECT 1 FROM broadcasts WHERE status='queued' LIMIT 1")
            updates = api.call('getUpdates', offset=offset, timeout=0 if queued else 25,
                               allowed_updates=['message', 'callback_query'])
            for update in updates:
                offset = update['update_id']+1
                # Commit acknowledgement before side effects: no replay of key creation/ingestion.
                store.run("INSERT OR REPLACE INTO meta(key,value) VALUES('offset',?)", (str(offset),))
                try:
                    bot.handle(update)
                except (APIError, UncertainDelivery, ValueError, KeyError, OverflowError) as error:
                    LOG.warning('Update %s não concluído (%s). Use /start para recuperar o menu.',
                                update['update_id'], type(error).__name__)
            if queued:
                sent = bot.process_broadcast()
                time.sleep(0.1 if sent else 1)
        except APIError as error:
            if error.code in (401, 409):
                raise SystemExit('Token inválido ou outra instância está usando o bot.') from None
            LOG.warning('Telegram indisponível (%s); aguardando.', error.code)
            time.sleep(max(3, error.retry_after))
        except UncertainDelivery:
            LOG.warning('Falha de conexão; reconectando.')
            time.sleep(3)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    try:
        main()
    except KeyboardInterrupt:
        print('\nBot encerrado.')
