"""Small authenticated Telegram Mini App server sharing the bot's SQLite database."""
import base64
import hashlib
import hmac
import json
import logging
import mimetypes
import os
import requests
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

from storage import Store

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'webapp'
PAGE = 10
MAX_BODY = 29 * 1024 * 1024
LOG = logging.getLogger('miniapp')


def validate_init_data(raw, token, now=None):
    """Validate Telegram WebApp initData using the official WebAppData HMAC procedure."""
    if not isinstance(raw, str) or len(raw) > 16_384:
        raise ValueError('Invalid Telegram session')
    values = {}
    for pair in raw.split('&'):
        if '=' not in pair:
            continue
        key, value = pair.split('=', 1)
        from urllib.parse import unquote_plus
        values[unquote_plus(key)] = unquote_plus(value)
    supplied = values.pop('hash', None)
    values.pop('signature', None)  # Ed25519 signature is for third-party validation.
    if not supplied:
        raise ValueError('Invalid Telegram session')
    check = '\n'.join(f'{key}={values[key]}' for key in sorted(values))
    secret = hmac.new(b'WebAppData', token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, supplied):
        raise ValueError('Invalid Telegram session')
    try:
        auth_date = int(values['auth_date'])
        person = json.loads(values['user'])
        uid = int(person['id'])
    except (KeyError, ValueError, TypeError, json.JSONDecodeError):
        raise ValueError('Invalid Telegram session') from None
    current = int(time.time() if now is None else now)
    if auth_date > current+30 or current-auth_date > 86_400 or uid <= 0:
        raise ValueError('Expired Telegram session')
    return person


class MiniApp:
    def __init__(self, store, api, token, admins):
        self.s, self.api, self.token, self.admins = store, api, token, set(admins)
        self.db_path = Path(store.one('PRAGMA database_list')['file'])

    def user(self, person):
        return self.s.register(person)

    def require_access(self, uid):
        user = self.s.user(uid)
        if not user:
            raise ValueError('Open the bot and press Start first')
        if user['banned']:
            raise PermissionError('Access blocked')
        if uid not in self.admins and user['expires'] <= time.time():
            raise PermissionError('Activate a valid key to continue')
        return user

    def init(self, person):
        row = self.user(person)
        return {'user': self.profile(person['id'], allow_locked=True),
                'admin': person['id'] in self.admins,
                'locked': person['id'] not in self.admins and row['expires'] <= time.time()}

    def profile(self, uid, allow_locked=False):
        user = self.s.user(uid)
        if user['banned']:
            raise PermissionError('Access blocked')
        if not allow_locked:
            self.require_access(uid)
        key = self.s.one('SELECT * FROM keys WHERE id=?', (user['current_key'],))
        count = self.s.one("SELECT count(*) n FROM downloads WHERE user_id=? AND status='sent'", (uid,))['n']
        return {'id': uid, 'username': user['username'], 'name': user['name'],
                'registered': user['registered'], 'language': user['lang'] or 'pt',
                'downloads': count, 'expires': user['expires'],
                'status': 'admin' if uid in self.admins else ('active' if user['expires'] > time.time() else 'inactive'),
                'key_id': key['id'] if key else None, 'key_days': key['days'] if key else None}

    def catalog(self, uid, page=0, news=False):
        user = self.require_access(uid)
        if not isinstance(page, int) or page < 0:
            raise ValueError('Invalid page')
        condition = 'f.active=1'
        args = []
        if news:
            condition += " AND NOT EXISTS (SELECT 1 FROM downloads d WHERE d.user_id=? AND d.file_id=f.id AND d.status='sent')"
            args.append(uid)
        total = self.s.one('SELECT count(*) n FROM files f WHERE '+condition, args)['n']
        page = min(page, max(0, (total-1)//PAGE))
        items = self.s.all('SELECT f.id,f.display_id,f.title,d.status FROM files f '
                           'LEFT JOIN downloads d ON d.user_id=? AND d.file_id=f.id WHERE '+condition+
                           ' ORDER BY f.id LIMIT ? OFFSET ?', [uid, *args, PAGE, page*PAGE])
        return {'items': [{'id': x['id'], 'number': x['display_id'] or x['id'], 'title': x['title'],
                           'downloaded': x['status'] == 'sent', 'pending': x['status'] == 'pending'} for x in items],
                'page': page, 'pages': max(1, (total+PAGE-1)//PAGE), 'total': total, 'news': news,
                'expires': user['expires']}

    def download(self, uid, fid):
        user = self.require_access(uid)
        result = self.s.reserve(uid, fid, uid in self.admins)
        if result != 'reserved':
            return {'status': result}
        file = self.s.one('SELECT * FROM files WHERE id=? AND active=1', (fid,))
        try:
            message = self.api.call('copyMessage', chat_id=uid, from_chat_id=file['source_chat'],
                                    message_id=file['source_message'])
        except Exception as error:
            from bot import APIError, UncertainDelivery
            if isinstance(error, APIError) and error.code in (400, 403, 429):
                self.s.run('DELETE FROM downloads WHERE user_id=? AND file_id=?', (uid, fid))
                return {'status': 'failed'}
            self.s.run("UPDATE downloads SET status='pending' WHERE user_id=? AND file_id=?", (uid, fid))
            return {'status': 'uncertain'}
        self.s.run("UPDATE downloads SET status='sent',message_id=? WHERE user_id=? AND file_id=?",
                   (message['message_id'], uid, fid))
        return {'status': 'sent'}

    def redeem(self, uid, key):
        result = self.s.redeem(uid, key)
        if result != 'activated':
            raise ValueError({'invalid_key': 'Invalid, expired or used key',
                              'slow': 'Too many attempts. Try again later',
                              'banned': 'Access blocked'}.get(result, result))
        return self.profile(uid)

    def admin_data(self, uid):
        self.is_admin(uid)
        files = self.s.all('SELECT * FROM files ORDER BY id DESC LIMIT 100')
        keys = self.s.all('SELECT * FROM keys ORDER BY id DESC LIMIT 100')
        users = self.s.all('SELECT * FROM users ORDER BY registered DESC LIMIT 100')
        broadcast = self.s.one("SELECT * FROM broadcasts WHERE admin_id=? AND status!='draft' ORDER BY id DESC LIMIT 1", (uid,))
        progress = None
        if broadcast:
            progress = {r['status']: r['n'] for r in self.s.all(
                'SELECT status,count(*) n FROM broadcast_recipients WHERE broadcast_id=? GROUP BY status', (broadcast['id'],))}
        return {'files': [{'id': f['id'], 'number': f['display_id'] or f['id'], 'title': f['title'], 'active': bool(f['active'])} for f in files],
                'keys': [{'id': k['id'], 'days': k['days'], 'used': bool(k['used_by']), 'revoked': bool(k['revoked']), 'expires': k['redeem_until']} for k in keys],
                'users': [{'id': u['id'], 'name': u['name'], 'username': u['username'], 'banned': bool(u['banned']), 'expires': u['expires']} for u in users],
                'broadcast': {'id': broadcast['id'], 'status': broadcast['status'], 'counts': progress} if broadcast else None}

    def is_admin(self, uid):
        if uid not in self.admins:
            raise PermissionError('Admin access required')
        if self.s.user(uid)['banned']:
            raise PermissionError('Access blocked')

    def admin_action(self, uid, action, data):
        self.is_admin(uid)
        if action == 'create_key':
            kid, raw = self.s.create_key(uid, int(data.get('days', 0)), int(data.get('redeem_days', 0)))
            return {'id': kid, 'key': raw}
        if action == 'toggle_file':
            fid = int(data['id'])
            self.s.run('UPDATE files SET active=? WHERE id=?', (int(bool(data['active'])), fid))
            self.s.log(uid, 'toggle', fid)
            return {'ok': True}
        if action == 'rename_file':
            fid, title = int(data['id']), str(data['title']).strip()[:60]
            if not title:
                raise ValueError('Enter a title')
            self.s.run('UPDATE files SET title=? WHERE id=?', (title, fid))
            self.s.log(uid, 'rename', fid)
            return {'ok': True}
        if action == 'rename_all':
            title = str(data['title']).strip()[:60]
            if not title:
                raise ValueError('Enter a title')
            with self.s.transaction():
                self.s.run('UPDATE files SET title=?', (title,))
                self.s.log(uid, 'rename_all')
            return {'ok': True}
        if action == 'delete_all':
            with self.s.transaction():
                removed = self.s.run('DELETE FROM files').rowcount
                self.s.run('UPDATE files SET display_id=id')
                self.s.run("UPDATE meta SET value='1' WHERE key='next_file_number'")
                self.s.log(uid, 'delete_all', removed)
            return {'removed': removed}
        if action == 'user_ban':
            target = int(data['id'])
            if target in self.admins:
                raise ValueError('Cannot ban an administrator')
            self.s.run('UPDATE users SET banned=? WHERE id=?', (int(bool(data['banned'])), target))
            self.s.log(uid, 'ban', target)
            return {'ok': True}
        if action == 'user_expire':
            target = int(data['id'])
            self.s.run('UPDATE users SET expires=0,current_key=NULL WHERE id=? AND id NOT IN ('+
                       ','.join('?' for _ in self.admins)+')', [target, *self.admins])
            self.s.log(uid, 'expire', target)
            return {'ok': True}
        if action == 'upload_file':
            name = re.sub(r'[^\w. -]', '_', str(data.get('name', 'file'))[:120]) or 'file'
            raw = base64.b64decode(data.get('content', ''), validate=True)
            if not raw or len(raw) > 20*1024*1024:
                raise ValueError('File must be between 1 byte and 20 MB')
            mime = mimetypes.guess_type(name)[0] or 'application/octet-stream'
            response = requests.post(self.api.base+'sendDocument', data={'chat_id': uid},
                                    files={'document': (name, raw, mime)}, timeout=(10, 90))
            result = response.json()
            if not result.get('ok'):
                raise ValueError('Telegram could not upload this file')
            message = result['result']
            title = name[:60]
            with self.s.transaction():
                number = int(self.s.one("SELECT value FROM meta WHERE key='next_file_number'")['value'])
                fid = self.s.run('INSERT INTO files(title,source_chat,source_message,display_id) VALUES(?,?,?,?)',
                                (title, uid, message['message_id'], number)).lastrowid
                self.s.run("UPDATE meta SET value=? WHERE key='next_file_number'", (str(number+1),))
                self.s.log(uid, 'add', fid)
            return {'id': fid, 'number': number, 'title': title}
        if action == 'announcement':
            text = str(data.get('text', '')).strip()
            content = data.get('content')
            if not text and not content or len(text) > 1024:
                raise ValueError('Announcement must be 1–4096 characters')
            if content:
                name = re.sub(r'[^\w. -]', '_', str(data.get('name', 'announcement'))[:120]) or 'announcement'
                raw = base64.b64decode(content, validate=True)
                if not raw or len(raw) > 20*1024*1024:
                    raise ValueError('Media must be between 1 byte and 20 MB')
                response = requests.post(self.api.base+'sendDocument', data={'chat_id': uid, 'caption': text},
                                         files={'document': (name, raw, mimetypes.guess_type(name)[0] or 'application/octet-stream')},
                                         timeout=(10, 90))
                result = response.json()
                if not result.get('ok'):
                    raise ValueError('Telegram could not upload this announcement')
                sent = result['result']
            else:
                if len(text) > 4096:
                    raise ValueError('Announcement must be at most 4096 characters')
                sent = self.api.call('sendMessage', chat_id=uid, text=text)
            with self.s.transaction():
                job = self.s.run('INSERT INTO broadcasts(admin_id,source_message,created) VALUES(?,?,?)',
                                 (uid, sent['message_id'], time.time())).lastrowid
                self.s.run('INSERT INTO broadcast_recipients(broadcast_id,user_id) SELECT ?,id FROM users', (job,))
                self.s.run("UPDATE broadcasts SET status='queued' WHERE id=?", (job,))
                self.s.log(uid, 'broadcast', job)
            return {'id': job}
        raise ValueError('Unknown admin action')


def make_handler(app):
    local = threading.local()
    class Handler(BaseHTTPRequestHandler):
        server_version = 'TelegramMiniApp'

        def log_message(self, fmt, *args):
            LOG.info('Mini App HTTP %s', args[1] if len(args) > 1 else '')

        def send(self, code, data, content='application/json; charset=utf-8'):
            body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header('Content-Type', content)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' https://telegram.org; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors https://web.telegram.org https://*.telegram.org")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == '/':
                path = '/index.html'
            target = (WEB / unquote(path.lstrip('/'))).resolve()
            if WEB.resolve() not in target.parents or not target.is_file():
                return self.send(404, {'error': 'Not found'})
            mime = mimetypes.guess_type(target.name)[0] or 'application/octet-stream'
            self.send(200, target.read_bytes(), mime+'; charset=utf-8' if mime.startswith(('text/', 'application/javascript')) else mime)

        def do_POST(self):
            if not self.path.startswith('/api/'):
                return self.send(404, {'error': 'Not found'})
            try:
                service = getattr(local, 'service', None)
                if service is None:
                    from bot import Telegram
                    connection = Store(app.db_path)
                    service = MiniApp(connection, Telegram(app.token), app.token, app.admins)
                    local.connection, local.service = connection, service
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= MAX_BODY:
                    return self.send(413, {'error': 'Request too large'})
                payload = json.loads(self.rfile.read(length))
                person = validate_init_data(payload.pop('initData', ''), service.token)
                row = service.user(person)
                uid = row['id']
                route = self.path.split('?', 1)[0]
                if route == '/api/init':
                    result = service.init(person)
                elif route == '/api/catalog':
                    result = service.catalog(uid, int(payload.get('page', 0)), bool(payload.get('news')))
                elif route == '/api/profile':
                    result = service.profile(uid, allow_locked=True)
                elif route == '/api/language':
                    lang = payload.get('language')
                    if lang not in ('pt', 'en', 'ru', 'zh'):
                        raise ValueError('Invalid language')
                    service.s.run('UPDATE users SET lang=? WHERE id=?', (lang, uid))
                    result = {'language': lang}
                elif route == '/api/key':
                    result = service.redeem(uid, str(payload.get('key', ''))[:100])
                elif route == '/api/download':
                    result = service.download(uid, int(payload.get('id', 0)))
                elif route == '/api/admin':
                    result = service.admin_data(uid)
                elif route.startswith('/api/admin/'):
                    result = service.admin_action(uid, route.rsplit('/', 1)[1], payload)
                else:
                    return self.send(404, {'error': 'Not found'})
                self.send(200, {'ok': True, 'result': result})
            except PermissionError as error:
                self.send(403, {'ok': False, 'error': str(error)})
            except ValueError as error:
                message = error.args[0]
                self.send(400, {'ok': False, 'error': message if isinstance(message, str) else 'Invalid key'})
            except (KeyError, TypeError, json.JSONDecodeError):
                self.send(400, {'ok': False, 'error': 'Invalid request'})
            except Exception as error:
                LOG.warning('Mini App request failed (%s)', type(error).__name__)
                self.send(500, {'ok': False, 'error': 'Temporary error'})

    return Handler


def start(app, host='127.0.0.1', port=8765):
    server = ThreadingHTTPServer((host, port), make_handler(app))
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, name='miniapp-http', daemon=True).start()
    LOG.info('Mini App server listening on %s:%s', host, port)
    return server
