# Bot de catálogo para Telegram

Bot Python com catálogo, assinaturas por key, quatro idiomas, painel admin e Telegram Mini App. Banco SQLite compartilhado.

## Configuração

Copie `.env.example` para `.env` e informe o token do BotFather e os IDs numéricos de administradores. Instale as dependências com `python -m pip install -r requirements.txt` e inicie `iniciar.ps1`.

O bot serve o Mini App em `http://127.0.0.1:8765`. O Telegram exige um endereço público **HTTPS** para abrir Mini Apps. Configure `MINIAPP_URL` com um endereço que encaminha para essa porta, então reinicie o bot. Se o URL estiver configurado, o bot ativa o botão **Files** no menu e `/app`.

Para experimentar com túnel temporário, instale `cloudflared` e execute `cloudflared tunnel --url http://127.0.0.1:8765`. Copie o endereço `https://...trycloudflare.com` informado para `MINIAPP_URL` no `.env` e reinicie. O túnel precisa continuar ativo; um domínio estável é mais adequado para uso contínuo. Mantenha a porta local ligada a `127.0.0.1`.

## O Mini App

O Mini App valida `Telegram.WebApp.initData` no servidor com HMAC e aplica as permissões no banco; o navegador nunca define quem é administrador. Ele compartilha arquivos, histórico de envios, assinaturas e idiomas com o bot. Oferece Arquivos, Novos (`/news`), Perfil e Administração. Admins podem enviar arquivos, gerir o catálogo, gerar keys, gerir usuários e enviar avisos de texto ou mídia. Cada aviso é confirmado antes de entrar na fila compartilhada de entregas.

Arquivos enviados no Mini App são enviados primeiro ao chat privado do admin pelo próprio bot; essa mensagem fica como origem do catálogo. Avisos aceitam uma mensagem de texto e, opcionalmente, um arquivo de até 20 MB. O arquivo enviado pelo navegador é tratado como documento. Os destinatários recebem cópias sem cabeçalho de encaminhamento. Mantenha as mensagens de origem até terminar a fila.

## Bot

Os menus do bot seguem disponíveis: `/start`, `/news`, `/profile`, `/app` e `/admin` (admins). Arquivos têm um envio por usuário; o estado confirmado é refletido tanto no bot quanto no Mini App. Keys são de resgate único. O painel inclui controle de arquivos, renomeação e exclusão em lote com reinício da numeração visível, keys, banimento, assinatura, estatísticas, auditoria e avisos em fila. Dados ficam em `data/catalog.sqlite3`; faça cópia de segurança com o bot parado.
