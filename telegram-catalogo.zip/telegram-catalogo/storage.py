import hashlib
import secrets
import sqlite3
import time
from contextlib import contextmanager


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path, isolation_level=None, timeout=10)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        PRAGMA journal_mode=WAL;
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, lang TEXT, banned INTEGER DEFAULT 0,
          expires REAL DEFAULT 0, current_key INTEGER, menu INTEGER, state TEXT DEFAULT '',
          failures INTEGER DEFAULT 0, locked_until REAL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS keys(
          id INTEGER PRIMARY KEY AUTOINCREMENT, digest TEXT UNIQUE NOT NULL,
          days INTEGER NOT NULL, redeem_until REAL NOT NULL, revoked INTEGER DEFAULT 0,
          used_by INTEGER, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS files(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          source_chat INTEGER NOT NULL, source_message INTEGER NOT NULL,
          active INTEGER DEFAULT 1, UNIQUE(source_chat,source_message));
        CREATE TABLE IF NOT EXISTS downloads(
          user_id INTEGER NOT NULL, file_id INTEGER NOT NULL, status TEXT NOT NULL,
          created REAL NOT NULL, message_id INTEGER,
          PRIMARY KEY(user_id,file_id));
        CREATE TABLE IF NOT EXISTS audit(
          id INTEGER PRIMARY KEY AUTOINCREMENT, actor INTEGER, action TEXT,
          target INTEGER, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS broadcasts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL,
          source_message INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'draft', created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS broadcast_recipients(
          broadcast_id INTEGER NOT NULL, user_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
          next_at REAL NOT NULL DEFAULT 0, message_id INTEGER,
          PRIMARY KEY(broadcast_id,user_id));
        CREATE INDEX IF NOT EXISTS broadcast_pending ON broadcast_recipients(status,next_at);
        ''')
        if 'display_id' not in {r['name'] for r in self.all('PRAGMA table_info(files)')}:
            self.run('ALTER TABLE files ADD COLUMN display_id INTEGER')
            self.run('UPDATE files SET display_id=id')
        self.run("INSERT OR IGNORE INTO meta(key,value) VALUES('next_file_number',?)",
                 (str(self.one('SELECT coalesce(max(coalesce(display_id,id)),0)+1 n FROM files')['n']),))
        columns = {r['name'] for r in self.all('PRAGMA table_info(users)')}
        for name, definition in {'username': 'TEXT', 'registered': 'REAL',
                                 'navigation': "TEXT DEFAULT '[\"home\"]'"}.items():
            if name not in columns:
                self.run(f'ALTER TABLE users ADD COLUMN {name} {definition}')

    def one(self, sql, args=()):
        return self.db.execute(sql, args).fetchone()

    def all(self, sql, args=()):
        return self.db.execute(sql, args).fetchall()

    def run(self, sql, args=()):
        return self.db.execute(sql, args)

    @contextmanager
    def transaction(self):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def user(self, uid):
        return self.one('SELECT * FROM users WHERE id=?', (uid,))

    def register(self, person):
        self.run('INSERT INTO users(id,name,username,registered) VALUES(?,?,?,?) '
                 'ON CONFLICT(id) DO UPDATE SET name=excluded.name,username=excluded.username',
                 (person['id'], person.get('first_name', '')[:80], person.get('username'), time.time()))
        return self.user(person['id'])

    def log(self, actor, action, target=0):
        self.run('INSERT INTO audit(actor,action,target,created) VALUES(?,?,?,?)',
                 (actor, action, target, time.time()))

    def create_key(self, actor, days, redemption_days):
        if not 1 <= days <= 3650 or not 1 <= redemption_days <= 3650:
            raise ValueError('days')
        raw = 'CAT-' + secrets.token_hex(16).upper()
        with self.transaction():
            kid = self.run('INSERT INTO keys(digest,days,redeem_until,created) VALUES(?,?,?,?)',
                          (self.digest(raw), days, time.time()+redemption_days*86400, time.time())).lastrowid
            self.log(actor, 'create', kid)
        return kid, raw

    @staticmethod
    def digest(raw):
        return hashlib.sha256(raw.strip().upper().encode()).hexdigest()

    def redeem(self, uid, raw):
        now = time.time()
        with self.transaction():
            user = self.user(uid)
            if user['banned']:
                return 'banned'
            if user['locked_until'] > now:
                return 'slow'
            key = self.one('SELECT * FROM keys WHERE digest=?', (self.digest(raw),))
            if not key or key['revoked'] or key['used_by'] is not None or key['redeem_until'] <= now:
                attempts = user['failures'] + 1 if user['locked_until'] == 0 else 1
                self.run('UPDATE users SET failures=?,locked_until=? WHERE id=?',
                         (0 if attempts >= 5 else attempts, now+900 if attempts >= 5 else 0, uid))
                return 'slow' if attempts >= 5 else 'invalid_key'
            self.run('UPDATE keys SET used_by=? WHERE id=?', (uid, key['id']))
            self.run('UPDATE users SET expires=?,current_key=?,failures=0,locked_until=0,state=\'\' WHERE id=?',
                     (now+key['days']*86400, key['id'], uid))
            self.log(uid, 'activated', key['id'])
        return 'activated'

    def reserve(self, uid, fid, admin=False):
        with self.transaction():
            user = self.user(uid)
            if user['banned']:
                return 'banned'
            if not admin and user['expires'] <= time.time():
                return 'locked'
            file = self.one('SELECT * FROM files WHERE id=? AND active=1', (fid,))
            if not file:
                return 'unavailable'
            previous = self.one('SELECT status FROM downloads WHERE user_id=? AND file_id=?', (uid, fid))
            if previous:
                return 'sent' if previous['status'] == 'sent' else 'uncertain'
            self.run('INSERT INTO downloads(user_id,file_id,status,created) VALUES(?,?,?,?)',
                     (uid, fid, 'pending', time.time()))
        return 'reserved'
